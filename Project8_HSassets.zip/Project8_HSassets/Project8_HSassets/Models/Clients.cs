﻿namespace Project8_HSassets.Models

{
    public class Client
    {
        //Fields

        public string Name;
        public string Branch;
        public int Clientid;        
        
        //Constructors

        //Methods
    }
}
